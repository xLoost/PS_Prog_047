#include <stdio.h>
#include <stdlib.h>

float radianos_graus(float rad)
{
    float g;

    g=(rad*180)/3.14159265359;

    return (g);
}


int main()
{
    float r;

    scanf("%f", &r);
    printf("%.1f\n", radianos_graus(r));
    return 0;
}
