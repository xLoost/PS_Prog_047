#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void converter(int h){

    int mes, sem, min, seg, ms, i;
    int lista[5];

    printf("[");
    for (i=0;i<5;i++){
        if (i==0){
            mes=h/720;
            lista[i]=mes;
        }
        if (i==1){
            sem=h/168;
            lista[i]=sem;
        }
        if (i==2){
            min=h*60;
            lista[i]=min;
        }
        if (i==3){
            seg=h*3600;
            lista[i]=seg;
        }
        if (i==4){
            ms=h*3600000;
            lista[i]=ms;
        }
        if (i!=4){
            printf("%d,", lista[i]);
        }
            else{
                printf("%d", lista[i]);
            }
    }
    printf("]\n");
}

int main()
{

    int h;
    scanf("%d", &h);
    converter(h);

    return 0;
}
