#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int conta_uns(int n){
    int q=0, t, i;
    char bin[30];

    itoa(n,bin,2);
    t=strlen(bin);

    for (i=0;i<t;i++){
        if (bin[i]=='1'){
            q++;
        }
    }

    return (q);
}

int main()
{
    int num;

    scanf("%d", &num);
    printf("%d\n", conta_uns(num));

    return 0;
}
