#include <stdio.h>
#include <stdlib.h>

void repeti(char item[30],int n){
    int i;

    printf("[");
    for (i=0;i<n;i++){
        if (i!=n-1){
            printf("\"%s\",", item);
        }
            else{
                printf("\"%s\"", item);
            }
    }
    printf("]");
}

int main()
{
    int n;
    char item[30];

    scanf("%[^\n]s", item);
    fflush(stdin);
    scanf("%d", &n);

    repeti(item, n);

    return 0;
}
