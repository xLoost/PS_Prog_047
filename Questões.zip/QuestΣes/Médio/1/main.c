#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double distancia(float ax, float ay, float bx, float by){
     double dist;

    dist=sqrt((pow((bx-ax), 2)+pow((by-ay), 2)));

    return (dist);
}

int main()
{
    float ax, ay, bx, by;

    printf("Digite as coordenadas do ponto a (x e y) e depois do ponto b,\nrespectivamente e espacadas por 1\n");
    scanf("%f %f %f %f", &ax, &ay, &bx, &by);
    printf("%.2f\n", distancia(ax, ay, bx, by));

    return 0;
}
