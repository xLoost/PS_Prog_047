#include <stdio.h>
#include <stdlib.h>

void crossbots(int n){

    while (1){
        if (n%15==0){
            char f[]="CrossBots";
            printf("%s\n", f);
            break;
        }
        if (n%3==0){
            char f[]="Cross";
            printf("%s\n", f);
            break;
        }
        if (n%5==0){
            char f[]="Bots";
            printf("%s\n", f);
            break;
        }
        printf("%d\n", n);
        break;
    }

}

int main()
{
    int num;

    scanf("%d", &num);
    crossbots(num);

    return 0;
}
